## Cobblemon Snack Alert
It must surely be annoying to have to be constantly checking to see if your Poké Snack has yielded any spawns, and it must be especially frustrating to see which Pokémon spawned. This addon fixes that, immediately alerting the player who placed down the Poké Snack of any new spawns and which species they belong to! You'll never miss out on any of those ultra-rare spawns again!

How It Works:
- Every time a Poké Snack successfully spawns a new Pokémon, the player who placed the snack will be alerted
- Only the owner of the Poké Snack will be alerted, no unwanted guests will know of your sweet finds!
- The player will be alerted of the Pokémon's species, but it is still up to them to check out any secondary characteristics

[Modrinth Page](https://modrinth.com/datapack/cobblemon-snack-alert)

## How To Install
This addon must be installed as a Data Pack

Data Pack:
- When creating your Minecraft world, press `[More]`
- Select `[Data Packs]`
- Drag and drop the Snack Alert .zip file into the data packs page OR press `[Open Pack Folder]` and place it there
- Activate the data pack in-game

*OR*

- For existing worlds, select the world and press `[Edit]`
- Select `[Open World Folder]`
- Navigate to the folder called `[datapacks]` (should be near the top)
- Drag and drop the Snack Alert .zip file into the folder (no data pack activation needed!)

## Project Members
- [Instrafe](https://gitlab.com/instrafe)

## License
This project is licensed under the MIT License. In summary, you are allowed to make and distribute forks of this project, so long as credit is given